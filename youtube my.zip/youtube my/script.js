var lord = document.querySelector(".lorder");
var lordd = document.querySelector(".lord");

lord.addEventListener("click" , ()=> {
    // setTimeout(() => {
        lordd.style.width = "100%";
        console.log("clicked")
    // }, 1000);
});

//                      clock  info 

function updateClock() {
    const clockElement = document.getElementById('clock');
    const now = new Date();
    
    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');
    // const seconds = String(now.getSeconds()).padStart(2, '0');
    
    clockElement.textContent = `${hours}:${minutes}`;
}

setInterval(updateClock, 1000);
updateClock(); // Initial call to display clock immediately


//                         end  

//       time show date  

var cl = document.querySelector("#clock");
var clt = document.querySelector("#clt");

cl.addEventListener("mouseenter" , ()=>{
    clt.style.display = "block";
    clt.style.opacity = "0.8";
});

cl.addEventListener("mouseleave" , ()=>{
    clt.style.display = "none";
    clt.style.opacity = "1";
});

//                setting of the search api 

